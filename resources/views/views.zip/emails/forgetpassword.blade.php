<html>
    <head>
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Permintaan Reset Password</div>
                          <div class="card-body">
                            <a href="http://localhost:8000/reset/{{$token}}">Klik Disini untuk melakukan reset password</a>
                          </div>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </body>
</html>
